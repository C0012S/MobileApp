package com.example.project_1;

public class SiteInfo {
    String site_name = "";
    String url = "";
    String user = "";
    String pwd = "";
    String pwd_check = "";
}
