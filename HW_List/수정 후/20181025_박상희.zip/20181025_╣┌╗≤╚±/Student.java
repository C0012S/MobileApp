package com.example.hw_list;

public class Student {
    String mName = "";
    String mNumber = "";
    String mDepartment = "";
}
